<?php require_once "satellite.php"; ?>
<html>
<head>
	<title> Home Page</title>
	<link rel="stylesheet" type="text/css"
	href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
	<form action="home.php" method="post">
	

<h3><center>Welcome to the home page</center> </h3>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

 <div><center><input type="submit" name="logout" class="login10" value="Log out"></center></div>

<style>
body{
	margin: 0;
	padding: 0;
	background: url(bgbg.jpg);
	background-size: cover;
	background-position: center;
	font-family: sans-serif;
}
.loginbox{
width: 320px;
	height: 390px;
	background: #000;
	top: 50%;
	left: 50%;
	position: absolute;
	transform: translate(-50%, -50%);
	box-sizing: border-box;
	padding: 70px 30px;
	background: rgba(0,0,0,0.7);
	border-radius: 10px;
	color: #fff;
}
.loginbox h3{
	text-align: center;
	text-decoration: none;
	font-size: 20px;
	line-height: 20px;
	color: white;
}
.loginbox .button
{
border: none;
    outline: none;
    height: 40px;
    background: white;
    color: black;
    font-size: 18px;
    border-radius: 10px
}

.login10{
	border-top: none;
	border-left: none;
	border-bottom:solid black;
	border-right: solid black;
	background: white;
	width: 20%;
	margin-left: auto;
	margin-right: auto;
</style>
</form>


</body>
</html>